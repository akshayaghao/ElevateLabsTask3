package LibraryManagementSystem;

public class User {
    private int id;
    private String name;
    private Book borrowedBook;

    
    public User(int id, String name, Book borrowedBook) {
        this.id = id;
        this.name = name;
        this.borrowedBook = borrowedBook;
    }

    
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Book getBorrowedBook() {
        return borrowedBook;
    }

    
    public void borrowBook(Book book) {
        this.borrowedBook = book;
    }

  
    public void returnBook() {
        this.borrowedBook = null;
    }

    
    @Override
    public String toString() {
        if (borrowedBook != null) {
            return "User ID: " + id + ", Name: " + name + ", Borrowed Book: " + borrowedBook.getTitle();
        } else {
            return "User ID: " + id + ", Name: " + name + ", Borrowed Book: None";
        }
    }
}
