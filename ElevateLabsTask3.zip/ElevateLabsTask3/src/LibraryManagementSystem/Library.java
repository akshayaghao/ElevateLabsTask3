package LibraryManagementSystem;

import java.util.ArrayList;

public class Library {

    private ArrayList<Book> books = new ArrayList<>();
    private ArrayList<User> users = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void viewBooks() {
        for (Book book : books) {
            System.out.println(book);
        }
    }

    public void viewUsers() {
        for (User user : users) {
            System.out.println(user);
        }
    }

    public void issueBook(int userId, int bookId) {
        User user = findUserById(userId);
        Book book = findBookById(bookId);

        if (user == null || book == null) {
            System.out.println("User OR Book Not Found In our System.");
            return;
        }

        if (book.isIssued()) {
            System.out.println("Book Is Already Issued");
            return;
        }

        if (user.getBorrowedBook() != null) {
            System.out.println("User Has Already Borrowed A Book.");
            return;
        }

        user.borrowBook(book);
        book.setIssued(true);
        System.out.println("Book Is Issued To " + user.getName());
    }

    public void returnBook(int userId) {
        User user = findUserById(userId);

        if (user == null || user.getBorrowedBook() == null) {
            System.out.println("No Borrowed Book To Return");
            return;
        }

        Book book = user.getBorrowedBook();
        book.setIssued(false);
        user.returnBook(); // <-- make sure this exists in User class
        System.out.println("Book Returned Successfully");
    }

    private User findUserById(int id) {
        for (User u : users) {
            if (u.getId() == id)
                return u;
        }
        return null;
    }

    private Book findBookById(int id) {
        for (Book b : books) {
            if (b.getId() == id)
                return b;
        }
        return null;
    }
}
