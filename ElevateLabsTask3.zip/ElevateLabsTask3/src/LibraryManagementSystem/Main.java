package LibraryManagementSystem;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
	
	
Library library= new Library();
Scanner sc = new Scanner(System.in);
int choice;

do {
	
	System.out.println("\n *** Library Management System *** ");
	System.out.println("1.Add Book");
	System.out.println("2.Add User");
	System.out.println("3.View Books");
	System.out.println("4.View Users");
	System.out.println("5.Issue Book");
	System.out.println("6.Return Book");
	System.out.println("7.Exit");
	
	System.out.print("Enter Your Choice For A Book : ->");
	choice = sc.nextInt();
	
	switch (choice) {
	case 1:
		System.out.print("Book ID :");
		int bId = sc.nextInt();
		sc.nextLine();
		
		System.out.print("Title :");
		String title = sc.nextLine();
		System.out.print("Author :");
		String author = sc.nextLine();
		library.addBook(new Book(bId, title, author));
		break;
		
		
	case 2:
		System.out.print("User Id :");
		int uId = sc.nextInt();
		sc.nextLine();
		System.out.print("Name : ");
		String name = sc.nextLine();
		library.addUser(new User(uId, name, null));
         break;
         
	case 3:
		
		library.viewBooks();
		break;
		
case 4:
		
		library.viewUsers();
		break;
		
		
case 5:
	
	System.out.print("Enter User ID :");
	int uid = sc.nextInt();
	System.out.print("Enter Book ID :");
	int bid = sc.nextInt();
	library.issueBook(uid, bid);
	break;
	
case 6:
	System.out.print("Enter User ID :");
	int returnId = sc.nextInt();
	library.returnBook(returnId);
	break;
	
case 7:
	System.out.println("Thank For Using Library System Of College of Engineering Pune");
	break;
	
	
	default:
		System.out.println("Invalid Choice");
		
	}
	

}while(choice !=7);



}

}
